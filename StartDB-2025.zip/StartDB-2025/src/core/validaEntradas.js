import { temDuplicados } from "../utils/validacoes.js";

export function validaEntradas(p1, p2, ordemAnimais, animaisValidos, brinquedosValidos) {
  if (temDuplicados(p1) || temDuplicados(p2)) {
    return { erro: "Brinquedo inválido" };
  }

  if (temDuplicados(ordemAnimais)) {
    return { erro: "Animal inválido" };
  }

  for (let a of ordemAnimais) {
    if (!animaisValidos.includes(a)) {
      return { erro: "Animal inválido" };
    }
  }

  for (let b of [...p1, ...p2]) {
    if (!brinquedosValidos.includes(b)) {
      return { erro: "Brinquedo inválido" };
    }
  }

  return { ok: true };
}
